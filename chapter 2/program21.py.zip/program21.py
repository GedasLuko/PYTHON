#Gediminas Lukosevicius
#August 31st, 2016 ©
# This program displays five questions and answers
# 1.What is your full name and section number of COP1000 class
# 2.What is the name of function that converts a string to a floating point number?
# 3.What is the symbol used to start a Python comment?
# 4.What is the Python data type used for numbers without decimals?
# 5.What is the purpose of the \t escape character?

#Display the question and answer 1.
question1 = input('Whats is your full name and section number of COP1000 class?')
full_name = 'My name is Gediminas Lukosevicius,'
section_number = 'the section number of this class is 2934.'
print(full_name, section_number)

#Display the question and answer 2.
question2 = input('What is the name of function that converts a string to a floating point number?')
function_name = 'The "int()" function converts a string to a floating point number.'
print(function_name)

#Display the question and answer 3.
question3 = input('What is the symbol used to start a Python comment?')
comment_symbol = 'The symbol used to start a Python comment is a #.'
print(comment_symbol)

#Display the question and answer 4.
question4 = input('What is the Python data type used for a number without decimals?')
data_type = 'The data type used for a number without decimals is called a "float".'
print(data_type)

#Display the question and answer 5.
question5 = input('What is the purpose of the \ t escape character?')
purpose = 'The purpose of the \ t escape character is to advance to the next horizontal tab position.'
print(purpose)
















